"""ForgeBoss validated learning layer."""
